<?php

class EasyNoteController extends API
{
    public function loginAction()
    {
        if ($_POST) {
            $user = $_POST['user'];
            $pwd = $_POST['pwd'];
        } else {
            $user = $_GET['user'];
            $pwd = $_GET['pwd'];
        }
        $model = $this->instance('user');
        $state= $model->login($user, $pwd);
        $jsonStr = json_encode($state);
        if (is_array($state)) {
            echo $jsonStr;
        } else {
            echo '{"mes":"Success!", "code":"100"}';
        }
    }

    public function getNoteListAction()
    {
        $M = new getNoteListModel();
        $list = $M->getList();
        echo json_encode($list);
    }
}