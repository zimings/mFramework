<?php

class getNoteListModel extends API
{
    public function getList()
    {
        $model=$this->instance('easyNote');
        $list = $model->getList();
        return $list;
    }
}