腾讯云短信 PHP SDK Demo
===

## 使用

1. 安装依赖

```sh
php /path/to/composer install
```

2. 配置必要参数，如SDK appid/appkey

```sh
emacs app.php
```

3. 运行

```sh
php ./app.php
```
