腾讯云短信 PHP SDK DEMO
=====


## 使用composer

使用composer的项目请参考 `composer` 目录


## 不使用composer

没有使用composer的项目请参考 `simple` 目录
