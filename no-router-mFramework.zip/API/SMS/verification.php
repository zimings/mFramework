<?php
/**
 * Created by PhpStorm.
 * User: 61534
 * Date: 2019/1/14
 * Time: 下午 01:55
 */
require "qcloudsms_php/src/index.php";

$appid = 1400178248; // 1400开头
$appkey = "37e219c895a48b0f0b313e2a3690f4a4";
$phoneNumber = $_GET['phone'];
$templateId = 265923;  // NOTE: 这里的模板ID`7839`只是一个示例，真实的模板ID需要在短信控制台中申请
$smsSign = "zimings"; // NOTE: 这里的签名只是示例，请使用真实的已申请的签名，签名参数使用的是`签名内容`，而不是`签名ID`

function make_password( $length = 4 )
{
    // 密码字符集，可任意添加你需要的字符
    /*$chars = array('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h',
        'i', 'j', 'k', 'l','m', 'n', 'o', 'p', 'q', 'r', 's',
        't', 'u', 'v', 'w', 'x', 'y','z', 'A', 'B', 'C', 'D',
        'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L','M', 'N', 'O',
        'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y','Z',
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9');*/
    $chars = array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
    // 在 $chars 中随机取 $length 个数组元素键名
    $keys = array_rand($chars, $length);
    $password = '';
    for($i = 0; $i < $length; $i++)
    {
        // 将 $length 个数组元素连接成字符串
        $password .= $chars[$keys[$i]];
    }
    return $password;
}


use Qcloud\Sms\SmsSingleSender;
try {
    $time = '1';
    $startTime =
    $code = make_password(6);
    $ssender = new SmsSingleSender($appid, $appkey);
    $params = [$code, $time];//数组具体的元素个数和模板中变量个数必须一致，例如事例中 templateId:5678对应一个变量，参数数组中元素个数也必须是一个
    $result = $ssender->sendWithParam("86", $phoneNumber, $templateId, $params, $smsSign);  // 签名参数未提供或者为空时，会使用默认签名发送短信
    $rsp = json_decode($result);
    $rsp->startTime = time();
    $rsp->code = $code;
    $rsp = json_encode($rsp);
    echo $rsp;
} catch(\Exception $e) {
    var_dump($e);
}