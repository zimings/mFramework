<?php
class SMSController extends API
{
    public function verificationAction()
    {
        include 'verification.php';
    }
}