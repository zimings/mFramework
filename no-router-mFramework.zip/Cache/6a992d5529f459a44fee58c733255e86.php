<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <title>Welcome</title>
    
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
    <script src="/no-router-mFramework/App/Static/library/jquery/jquery-3.3.1.min.js"></script>
    <script src="/no-router-mFramework/App/Static/library/jquery/jquery.cookie.js"></script>
    <link rel="stylesheet" type="text/css" href="/no-router-mFramework/App/Static/library/bootstrap/css/bootstrap.min.css">
    <script src="/no-router-mFramework/App/Static/library/bootstrap/js/bootstrap.min.js"></script>
    <script src="/no-router-mFramework/App/Static/js/Label/label.js"></script>
    <link rel="stylesheet" type="text/css" href="/no-router-mFramework/App/Static/css/Label/label.css">
    <script>$(function(){$("body").fadeIn(300)});</script>
    <style>body{display: none;}</style>
    
    <link rel="stylesheet" type="text/css" href="/no-router-mFramework/App/Static/css/style.css">
</head>
<body>

        <nav class="navbar navbar-default navbar-static-top">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand" href="/no-router-mFramework/">mFramework</a>
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <div class="collapse navbar-collapse" id="navbar-collapse">
                    <ul class="nav navbar-nav">
                        
    <?php if($name_self!=''){ ?>
    <li><a href="/no-router-mFramework/?c=user&a=home"><?php echo $this->value['name_self']; ?></a></li>
    <li><a href="/no-router-mFramework/?c=user&a=logout">退出</a></li>
    <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">我的收藏<span class="caret"></span></a>
        <ul class="dropdown-menu">
            <li><a href="#">开发中。。。</a></li>
        </ul>
    </li>
    <?php }else{ ?>
    <li><a href="/no-router-mFramework/?c=user&a=login">请登陆</a></li>
    <?php } ?>
    
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">功能<span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                
    <li><a href="/no-router-mFramework/?c=app&a=form">表单向导</a></li>
    <li><a href="/no-router-mFramework/?c=app&a=show">小部件展示</a></li>
    
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">推荐<span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                
    <li><a target="_blank" href="https://www.glyphicons.com/">Glyphicons 字体图标</a></li>
    
                            </ul>
                        </li>
                    </ul>
                    
                    <form class="navbar-form navbar-left" role="search" action="" target="_blank">
                        <div class="form-group">
                            <input type="hidden" value="search" name="c">
                            <input type="hidden" value="search" name="a">
                            <input type="hidden" name="flag" value="public">
                            <input id="nav_searchInput" type="text" class="form-control" placeholder="全站搜索" name="keyWords">
                        </div>
                        <button type="submit" class="btn btn-default">搜索</button>
                    </form>
                </div>
            </div>
        </nav>
        <div id="nav_messageBox"></div>
        <script>
        function showMsg(msg, time=1000) {
            var e = $("#nav_messageBox");
            if (e.css("display")==="block"){
                e.fadeOut(300).fadeIn(300);
                setTimeout(function() {e.text(msg)},300)
            } else {
                e.fadeIn(300).text(msg);
            }
            setTimeout(function() {
                e.fadeOut(300)
            }, time)
        }
        </script>
        
<div class="container-fluid">
    <h1>Welcome!</h1>
    <div class="row">
        <div class="col-sm-3"></div>
        <!-- 文章列表 -->
        <div class="col-sm-6 contentBox">
            <?php echo $this->value['content']; ?>
        </div>
        <div class="col-sm-3"></div>
    </div>
</div>
<div class="footer col-md-12" style="margin-top: 30px;">
    <ul style="list-style-type: none;text-align: center;padding: 0;">
        <li>Copyright &copy; 2017-<span id="footer_nowYear"></span>, mFramework, All rights reserved</li>
        <li>鲁ICP备17053237号</li>
    </ul>
</div>
<div id="backTopBtn" onclick="backTop()">
    <span class="glyphicon glyphicon-chevron-up"></span>
</div>
<script>
    var date = new Date();
    var year = date.getFullYear();
    $('#footer_nowYear').text(year);

    function backTop(minHeight) {
        $('#backTopBtn').click(function () {
            $('html, body').animate({scrollTop: 0}, 200)
        });

        minHeight ? minHeight = minHeight : minHeight = 20;

        $(window).scroll(function () {
            var s = $(window).scrollTop();

            if (s > minHeight) {
                $('#backTopBtn').fadeIn(100)
            } else {
                $('#backTopBtn').fadeOut(100)
            }
        })
    }

    backTop()
</script>
</body>
</html>