<?php
function editor($Attr) {
    $editor = '
        var E = window.wangEditor;
        var editor = new E(\'#editor\');
        editor.customConfig.menus = [
            \'bold\',  // 粗体
            \'fontSize\',  // 字号
            \'underline\',  // 下划线
            \'foreColor\',  // 文字颜色
            \'backColor\',  // 背景颜色
            \'link\',  // 插入链接
            \'list\',  // 列表
            \'justify\',  // 对齐方式
            \'quote\',  // 引用
            \'image\',  // 插入图片
        ];
        editor.customConfig.uploadImgShowBase64 = true; // 使用 base64 保存图片
        
        function submitArticle() {
            var titleEle = $(\'#title\');
            $(\'#content\').val(editor.txt.html());
            var contentText = editor.txt.text();
            var otherInfoEle = $(\'#otherInfoBox .panel-body\').find(\'input\');
            var otherInfo = {};
            for (var i of otherInfoEle) {
                otherInfo[i.id] = i.value.replace(/<[^>]*>/, "");
            }
            $(\'#otherInfo\').val(JSON.stringify(otherInfo));
            if (titleEle.val()===\'\') {
                titleEle.val(contentText.slice(0, 25).replace(/<[^>]*>/, ""));
            }else{
                titleEle.val(titleEle.val().replace(/<[^>]*>/, ""));
            }
            if (contentText===\'\') {
                var contentHelpEle = $(\'#contentHelp\');
                contentHelpEle.text(\'内容不能为空！\');
                contentHelpEle.parent().addClass(\'has-error\');
                return false;
            }
        }
    ';
    switch ($Attr['block']) {
        case 'editor':
            $data = $editor;
            break;
        default:
            $data = '';
    }
    return $data;
}