<?php
function nav($Attr)
{
    if (empty($Attr['flag'])) {
        $Attr['flag'] = 'public';
        $placeHoleder = '全站搜索';
    } elseif ($Attr['flag'] == 'personal') {
        $placeHoleder = '在您的文章中搜索';
    }
    $searchBox = '
                    <form class="navbar-form navbar-left" role="search" action="" target="_blank">
                        <div class="form-group">
                            <input type="hidden" value="search" name="c">
                            <input type="hidden" value="search" name="a">
                            <input type="hidden" name="flag" value="' . $Attr['flag'] . '">
                            <input id="nav_searchInput" type="text" class="form-control" placeholder="' . $placeHoleder . '" name="keyWords">
                        </div>
                        <button type="submit" class="btn btn-default">搜索</button>
                    </form>';
    if ($Attr['flag'] == 'search') {
        $searchBox = '';
    }
    // 功能菜单中的选项
    $list = '
    <li><a href="' . __WEB__ . '?c=app&a=form">表单向导</a></li>
    <li><a href="' . __WEB__ . '?c=app&a=show">小部件展示</a></li>
    ';
    // 推荐中的选项
    $recommended = '
    <li><a target="_blank" href="https://www.glyphicons.com/">Glyphicons 字体图标</a></li>
    ';
    // 加载用户信息
    $info = '
    {if $name_self!=\'\'}
    <li><a href="' . __WEB__ . '?c=user&a=home">{$name_self}</a></li>
    <li><a href="' . __WEB__ . '?c=user&a=logout">退出</a></li>
    <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">我的收藏<span class="caret"></span></a>
        <ul class="dropdown-menu">
            <li><a href="#">开发中。。。</a></li>
        </ul>
    </li>
    {else}
    <li><a href="' . __WEB__ . '?c=user&a=login">请登陆</a></li>
    {/if}
    ';
    // 信息汇总
    $data = '
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand" href="' . __WEB__ . '">mFramework</a>
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <div class="collapse navbar-collapse" id="navbar-collapse">
                    <ul class="nav navbar-nav">
                        ' . $info . '
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">功能<span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                ' . $list . '
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">推荐<span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                ' . $recommended . '
                            </ul>
                        </li>
                    </ul>
                    ' . $searchBox . '
                </div>
            </div>
        </nav>
        <div id="nav_messageBox"></div>
        <script>
        function showMsg(msg, time=1000) {
            var e = $("#nav_messageBox");
            if (e.css("display")==="block"){
                e.fadeOut(300).fadeIn(300);
                setTimeout(function() {e.text(msg)},300)
            } else {
                e.fadeIn(300).text(msg);
            }
            setTimeout(function() {
                e.fadeOut(300)
            }, time)
        }
        </script>
        ';
    return $data;
}