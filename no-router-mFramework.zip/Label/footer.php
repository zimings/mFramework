<?php
function footer($Attr) {
    return file_get_contents(__VIEW__.$Attr['file']);
}