<?php
function user($Attr) {
    foreach ($Attr as $key => $value) {
        if ($key=='login') {
            if ($value=='1') {
                $data = '
			<div class="userLoginBox">
				<div class="row">
					<div class="col-sm-6 col-sm-offset-6 form-group">
						<h1>登&nbsp;录</h1>
							<form action="'.__WEB__.'?c=user&a=login" class="form-horizontal" target="userLogin" method="post">
							<!-- 用户名输入框 -->
							<div class="form-group has-feedback">
								<label for="user" class="col-sm-2 control-label">账号</label>
								<div class="col-sm-10">
									<input class="form-control" type="text" id="user" name="user" placeholder="请输入用户名或手机号">
									<span class="help-block"></span>
									<span class="glyphicon form-control-feedback"></span>
								</div>
							</div>
							<!-- 密码输入框 -->
							<div class="form-group has-feedback">
								<label for="pwd" class="col-sm-2 control-label">密码</label>
								<div class="col-sm-10">
									<input class="form-control" type="password" id="pwd" name="pwd" placeholder="密码">
									<span class="help-block"></span>
									<span class="glyphicon form-control-feedback"></span>
								</div>
							</div>
							<!-- 引导注册 -->
							<div class="form-group">
								<div class="col-sm-offset-2 col-sm-10">
									<a href="'.__WEB__.'?c=user&a=registered">还没有账号？现在注册！</a>
								</div>
							</div>
							<!-- 提交按钮 -->
							<div class="form-group">
								<div class="col-sm-offset-2 col-sm-10">
									<input id="submit" class="btn btn-primary" type="submit" name="login" value="登录">
								</div>
							</div>
						</form>
						<iframe name="userLogin" style="display:none"></iframe>
					</div>
				</div>
			</div>';
            } else {
                $data = 'value error.';
            }

        }
        if ($key=='agreement') {
            if ($value=='1') {
                $data = '
			1、凡成功注册者均视为同意本协议。<br>
			2、本站现阶段为测试使用，不对用户做出任何承诺，不能保证用户信息的绝对安全。<br>
			3、最终解释权归本站所有。<br>
			';
            } else {
                $data = 'value error.';
            }
        }
    }
    return $data;
}