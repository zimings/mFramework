<?php
function rely($Attr) {
    $rely = '
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
    <script src="'.__LIB__.'jquery/jquery-3.3.1.min.js"></script>
    <script src="'.__LIB__.'jquery/jquery.cookie.js"></script>
    <link rel="stylesheet" type="text/css" href="'.__LIB__.'bootstrap/css/bootstrap.min.css">
    <script src="'.__LIB__.'bootstrap/js/bootstrap.min.js"></script>
    <script src="'.__JS__.'Label/label.js"></script>
    <link rel="stylesheet" type="text/css" href="'.__CSS__.'Label/label.css">
    <script>$(function(){$("body").fadeIn(300)});</script>
    <style>body{display: none;}</style>
    ';
    if (count($Attr)>0) {
        foreach ($Attr as $key => $value) {
            if ($key=='css') {
                $value = explode(",", $value);
                foreach ($value as $value) {
                    $addCss = '<link rel="stylesheet" type="text/css" href="'.__CSS__.'Label/'.$value.'.css">'.$addCss;
                }
            }
            if ($key=='js') {
                $value = explode(",", $value);
                foreach ($value as $value) {
                    $addJs = '<script src="'.__JS__.'Label/'.$value.'.js"></script>'.$addJs;
                }
            }
        }
    } else {
        $addCss = '';
        $addJs = '';
    }
    return $rely.$addCss.$addJs;
}