<?php
/**
 * base
 */

//引入接口
require 'interface.php';
// 加载控制器
require 'Controller.class.php';

class SysBase
{
    static $Config;

    public static function run()
    {
        function ifIsApi($api)
        {
            if (empty($api)) {
                return 0;
            } else {
                define('API', $api);
                include __API__ . 'api.class.php';
                $API = new API();
                $API->run();
                return 1;
            }
        }

        self::loadConfig();
        self::loadConstant();
        if (!ifIsApi(@$_GET['api'])) {
            if (!file_exists(__CONTROLLER__ . CONTROLLER . 'Controller.class.php')) {
                $urlData = 'errorPages' . DS . '404.html';
                Header("HTTP/1.1 404 Not Found");
                echo file_get_contents(__PUB__ . $urlData);
                exit();
            } else {
                // 初始化
                self::autoload();
                self::loadMethod();
            }
        }
    }

    private static function loadConfig()
    {
        //读取配置文件
        $json_string = file_get_contents(__ROOT__ . 'Core' . DS . 'config' . DS . 'Config.json');
        $Config = json_decode($json_string, 1);
        self::$Config = $Config;
        // 是否开启dBug
        if (self::$Config['dBug']) {
            ini_set("display_errors", "On");
            error_reporting(E_ALL ^ E_NOTICE);
        } else error_reporting(0);
    }

    private static function loadConstant()
    {
        //获取参数p 平台,c 控制器,a 动作
        define('PLATFORM', isset($_GET['p']) ? 'admin' : 'home');
        define('CONTROLLER', isset($_GET['c']) ? $_GET['c'] : 'index');
        define('ACTION', isset($_GET['a']) ? $_GET['a'] : 'index');
        //App path
        define('__APP__', __ROOT__ . 'App' . DS . (isset($_GET['app']) ? $_GET['app'] : self::$Config['Apps'][0]) . DS);
        //自定义标签
        define('__LABEL__', __ROOT__ . 'Label' . DS);
        //API
        define('__API__', __ROOT__ . 'API' . DS);
        //定义公共文件
        define('__PUB__', __ROOT__ . 'Public' . DS);
        //MODEL文件夹
        define('__MODEL__', __APP__ . 'Model' . DS);
        //CONTROLLER文件夹
        define('__CONTROLLER__', __APP__ . 'Controller' . DS . PLATFORM . DS);
        //VIEW文件夹
        define('__VIEW__', __APP__ . 'View' . DS);
        //域名下网站根目录
        $WEB = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
        define('__WEB__', $WEB == '/' ? '/' : $WEB . '/');
    }

    private static function loadMethod()
    {
        //获取控制器名称
        $controller_name = CONTROLLER . 'Controller';
        //获取动作名称
        $action_name = ACTION . 'Action';
        //实例化控制器对象
        $controller = new $controller_name();
        //调用方法
        $controller->$action_name();
    }

    //自动加载函数
    private static function load($classname)
    {
        if (substr($classname, -10) == 'Controller') {
            //载入控制器
            include __CONTROLLER__ . "{$classname}.class.php";
        } elseif (substr($classname, -5) == 'Model') {
            include __MODEL__ . "{$classname}.class.php";
        }
    }

    //注册为自动加载函数
    private static function autoload()
    {
        $arr = array(__CLASS__, 'load');
        spl_autoload_register($arr);
    }
}
