<?php
/*
 * Controller基类
 */

require 'TemplateEngine' . DS . 'Template.php';
require 'Model.class.php';

class Controller
{
    static $tpl;

    public function __construct()
    {
        self::$tpl = new Template();
        include __APP__ . 'setting.php';
        $setting = new setting();
        $setting->loadSetting();
    }

    public function render_once($data, $dataName = null)
    {
        if ($dataName == null) {
            self::$tpl->assign($data);
        } else {
            self::$tpl->assign($dataName, $data);
        }
    }

    public function render($template, $data = null, $dataName = null)
    {
        if ($dataName == null) {
            self::$tpl->assign($data);
        } else {
            self::$tpl->assign($dataName, $data);
        }
        self::$tpl->show($template);
    }
}
