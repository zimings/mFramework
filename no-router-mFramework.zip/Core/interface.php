<?php
/*app设置接口*/
interface settings
{
    /*应用设置*/
    public function loadSetting();
}