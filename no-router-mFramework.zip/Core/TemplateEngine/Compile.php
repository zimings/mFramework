<?php
/**
* 编译基类
*/
class Compile
{
    private $template;// 待编译的文件
    private $content;// 需要替换的文件
    private $comfile;// 编译后的文件
    private $T_P = array();// 正则
    private $T_R = array();// 替换内容
    function __construct($template, $compileFile, $config)
    {
        $this->template = $template;
        $this->comfile = $compileFile;
        $this->content = file_get_contents($template);
        if ($config['php_turn'] === true) {
            $this->T_P[] = "#<\?(=|php|)(.+?)\?>#is";
            $this->T_R[] = "&lt;?\1\2?&gt;";
        }
        // 变量匹配
        // \x7f-\xff表示ASCII字符从127到255，其中\为转义，作用是匹配汉字
        $this->T_P[] = "#\{\s*\\$([a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*)\s*\}#";
        $this->T_P[] = "#\{\s*\\$([a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*)\[\'([a-zA-Z_\x7f-\xff]+)\'\]\s*\}#";
        $this->T_P[] = "#\{\s*\\$([a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*)\->([a-zA-Z_\x7f-\xff]+)\s*\}#";
        $this->T_R[] = "<?php echo \$this->value['\\1']; ?>";
        $this->T_R[] = "<?php echo \$this->value['\\1']['\\2']; ?>";
        $this->T_R[] = "<?php echo \$this->value['\\1']->\\2; ?>";

        // foreach标签盘匹配
        $this->T_P[] = "#\{\s*(loop|foreach)\s+\\$([a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*)\s*\}#i";
        $this->T_P[] = "#\{\s*\/(loop|foreach|if)\s*\}#";
        $this->T_P[] = "#\{\s*([k|v])\s*\}#";
        $this->T_P[] = "#\{\s*([k|v])\[([a-zA-Z_\x7f-\xff\'\"0-9]+)\]+\s*\}#";
        $this->T_R[] = "<?php foreach ((array)\$this->value['\\2'] as \$k => \$v) { ?>";
        $this->T_R[] = "<?php } ?>";
        $this->T_R[] = "<?php echo \$\\1?>";
        $this->T_R[] = "<?php echo \$\\1[\\2]?>";
        // if else标签匹配
        $this->T_P[] = "#\{\s*if (.*?)\s*\}#";
        $this->T_P[] = "#\{\s*(else if|elseif) (.*?)\s*\}#";
        $this->T_P[] = "#\{\s*else\}#";
        $this->T_P[] = "#\{\s*(\#|\*)(.*?)(\#|\*)\s*\}#";
        $this->T_R[] = "<?php if(\\1){ ?>";
        $this->T_R[] = "<?php }elseif(\\2){ ?>";
        $this->T_R[] = "<?php }else{ ?>";
        $this->T_R[] = "";
    }
    public function staticLabel($htmlData)// 返回处理过后的HTML内容及label标签内容并添加标记
    {
        function loadAttr($label)
        {
            include __LABEL__.$label['name'].'.php';
            return $label['name']($label['attr']);// 传入属性
        }
        $changeUrls = array('{__CSS__}','{__JS__}','{__IMG__}','{__LIB__}','{__WEB__}','{ __CSS__ }','{ __JS__ }','{ __IMG__ }','{ __LIB__ }','{ __WEB__ }');
        $toChangeUrls = array(__CSS__,__JS__,__IMG__,__LIB__,__WEB__,__CSS__,__JS__,__IMG__,__LIB__,__WEB__);
        $htmlData = str_replace($changeUrls, $toChangeUrls, $htmlData);
        $getLabel = '/\{label:(\w+)\s*([^}]*)\}/';// 筛选label标签的正则表达式
        if (preg_match_all($getLabel, $htmlData, $labelData)) {// 匹配label标签内容
            $label = array();
            /*
             * $labelData[1] label名字
             * $labelData[2] label属性
             * $attrString 带着等号和引号的完整属性字符串数组
             * $attrArr 按照等号分离的属性及其值
             */
            for ($i=0; $i < count($labelData[1]); $i++) {
                //label名字
                $label['name'] = $labelData[1][$i];
                // 将属性的键值分开存放到$label['attr']
                $attrArr = array();
                $attrString = explode(' ', $labelData[2][$i]);
                // 将属性以=分开，放入数组中
                for ($j=0; $j < count($attrString); $j++) {
                    $attrArr[] = explode('=',$attrString[$j]);
                }
                // 将属性名放入数组索引，值放入数组值
                foreach ($attrArr as $value) {
                    for ($k=0; $k < 2; $k++) { 
                        if (strpos($value[1], '"') !== false) {
                            $label['attr'][$value[0]] = str_replace('"', '', $value[1]);
                        } elseif (strpos($value[1], "'") !== false) {
                            $label['attr'][$value[0]] = str_replace("'", '', $value[1]);
                        }
                    }
                }
                $htmlData = preg_replace($getLabel, loadAttr($label), $htmlData, 1);//加载label
                $label['attr'] = array();// 重置属性
            }
        }
        return $htmlData;
    }
    public function compile()
    {
        $this->content = $this->staticLabel($this->content);
        $this->c_var();
        //$this->c_staticFile();
        file_put_contents($this->comfile, $this->content);
    }
    public function c_var()
    {
        $this->content = preg_replace($this->T_P, $this->T_R, $this->content);
    }
    /* 对引入的静态文件进行解析，应对浏览器缓存 */
    public function c_staticFile()
    {
        $this->content = preg_replace('#\{\!(.*?)\!\}#', '<script src=\1'.'?t='.time().'></script>', $this->content);
    }
    public function __set($name, $value)
    {
        $this->$name = $value;
    }
    public function __get($name)
    {
        return $this->$name;
    }
}
