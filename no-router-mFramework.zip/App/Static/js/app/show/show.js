/*菜单按钮样式*/
function clickButton() {
	var a = $(".btnList-first").width();
	if (a==30) {
		$(".btnList-first").css({
			"width":"15px",
			"transform":"rotate(-30deg)",
			"top":"4px"
		});
		$(".btnList-thired").css({
			"width":"15px",
			"transform":"rotate(30deg)",
			"top":"12px"
		});
		$(".btnList-button").css({
			"transform":"rotate(360deg)"
		});
		$(".btnList-list").css("margin-left","0");
	} else {
		$(".btnList-first").css({
			"width":"30px",
			"transform":"rotate(0)",
			"top":"0"
		});
		$(".btnList-thired").css({
			"width":"30px",
			"transform":"rotate(0)",
			"top":"16px"
		});
		$(".btnList-button").css({
			"transform":"rotate(0)"
		});
		$(".btnList-list").css("margin-left","-100%");
	}
};