var publicElementId = 1;
var creatElementId = 1;
var radioIdIndex  = 1;
var radioId  = '';
var selectElementBox = '';
var selectElement = '';
var selectPreg = '常用正则：';
var model = '2';
// 公共函数
function ClickElement(id) {//用户点击元素时调用该函数
	var e = $('#'+id);
	selectElement = e.find('.element').attr('id');//获取选中元素的id，放入全局变量
	selectElementBox = id;//获取选中元素的最外层div的id，放入全局变量
	$('.elementBox').css('border','0px');
	var tagName = $('#'+id+'_what').val();//获取选中元素的标签名的区分值，该值存放在一个hidden的input里，由Creak()函数生成
	var left = $('.left');
	e.css('border','1px dashed #1ED6F2');//选中元素添加边框以区分
	var add = '';
	switch(tagName){
		case '0':
			var add = '\
				<label for="label">添加正则：</label>\
				<input onkeyup="ChangeAttr(this.id)" class="form-control" type="text" id="preg" value="'+e.find('#'+selectElement+'_preg').val()+'">\
				<select onchange="SelectChange(this.id)" id="'+selectElementBox+'_pregSelect" class="form-control element">\
					<option value="'+selectElementBox+'">'+selectPreg+'</option>\
					<option value="/^1[34578]\\d{9}$/">手机号</option>\
					<option value="/[a-zA-Z0-9]{1,8}/">字母或数字（1~8位）</option>\
					<option value="^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-z0-9]+[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+$">电子邮件</option>\
				</select>\
				<label for="label">添加输入错误后的提示信息：</label>\
				<input onkeyup="ChangeAttr(this.id)" class="form-control" type="text" id="mes" value="'+e.find('#'+selectElement+'_mes').val()+'">\
				';
			break;
		case '3':
			var arr = new Array();
			var option = $('#'+selectElement).find('option');
			for (var i = 0; i < option.length; i++) {
				var value=option.eq(i).val();
				arr.push(value);
			}
			var  str = '';
			for (var i = 0; i < arr.length; i++) {
				str = str+'\n'+arr[i];
			}
			var add = '\
				<label for="label">添加选项：</label>\
				<input onchange="ChangeAttr(this.id)" class="form-control" type="text" id="select" value="">\
				<span class="help-block">*通过添加选项添加的内容需要点一下其他地方才能显示出来。</span>\
				<label for="label">选项设置：</label>\
				<textarea onchange="addOption(this.id)" class="form-control" id="select">'+str+'</textarea>\
				<span class="help-block">*通过换行(\\n)隔开选项。</span>\
				';
			break;
		case '4':
			var margin = $('#'+selectElementBox).find('#radio_margin').val();
			var add = '\
				<label for="label">添加选项：</label>\
				<input onchange="ChangeAttr(this.id)" class="form-control" type="text" id="radio" value="">\
				<label for="label">调整间距：</label>\
				<input onkeyup="ChangeAttr(this.id)" class="form-control" type="text" id="margin" value="'+margin+'">\
				';
			break;
	}
	var data = '\
		<div class="form-group has-feedback">\
			<label for="label">设置名字：</label>\
			<input onkeyup="ChangeAttr(this.id)" class="form-control" type="text" id="name" value="'+e.find('label').text()+'">\
			<label for="label">设置透明度：</label>\
			<input onkeyup="ChangeAttr(this.id)" class="form-control" type="text" id="opacity" value="">\
			'+add+'\
			<button class="btn btn-danger" onclick="delElement()">删除这个元素</button>\
		</div>';
	left.html(data);
}
function ChangeAttr(id) {//由ClickElement()调用，用来改变editView内元素的属性
	var e = $('#'+id);
	var what = $('#'+selectElementBox+'_what').val();
	switch(id){
		case 'name':
			$('#'+selectElementBox).find('.control-label').text(e.val());
			$('#'+selectElementBox).find('.element').attr('name',e.val());
			if (what=='4') {
				$('#'+selectElementBox).find('.element').find('input[type="radio"]').attr('name',e.val());
				$('#'+selectElement).find("#radio_name").val(e.val());
			}
			break;
		case 'opacity':console.log(e.val())
			$('#'+selectElement).css('background','rgba(255,255,255,'+e.val()+')');
			break;
		case 'preg':
			if($('#'+selectElementBox).find('#'+selectElement+'_preg').length > 0) {
				$('#'+selectElementBox).find('#'+selectElement+'_preg').val(e.val());
			}else{
				$('#'+selectElementBox).find('.element').parent().append('<input id="'+selectElement+'_preg" type="hidden" value="'+e.val()+'">');
			}
			break;
		case 'mes':
			if($('#'+selectElementBox).find('#'+selectElement+'_mes').length > 0) {
				$('#'+selectElementBox).find('#'+selectElement+'_mes').val(e.val());
			}else{
				$('#'+selectElementBox).find('.element').parent().append('<input id="'+selectElement+'_mes" type="hidden" value="'+e.val()+'">');
			}
			break;
		case 'select':
			if (e.val()!='') {
				$('#'+selectElement).append("<option value='"+e.val()+"'>"+e.val()+"</option>");
			}
			break;
		case 'radio':
			var type = $('#'+selectElement).find("#radio_type").val();
			var name = $('#'+selectElement).find("#radio_name").val();
			$('#'+selectElement).append("<label class='radio-inline'><input id='radio"+radioIdIndex+"'' type='"+type+"' value='"+e.val()+"' name='"+name+"'>"+e.val()+'</label>');
			radioId = 'radio'+radioIdIndex;
			radioIdIndex++;
			break;
		case 'margin':
			$('#'+selectElement).find("#radio_margin").val(e.val());
			$('#'+selectElement).find(".radio-inline").css('margin-left',e.val()+'px');
			break;
	}
}
function Check(e) {
	if(p.test(e.val())) {
		e.parent().parent().addClass('has-success');
		e.parent().parent().removeClass('has-error');
		e.next().next().addClass('glyphicon-ok');
		e.next().next().removeClass('glyphicon-remove');
		e.next().html('');
		return true;
	}else{
		e.parent().parent().addClass('has-error');
		e.parent().parent().removeClass('has-success');
		e.next().next().addClass('glyphicon-remove');
		e.next().next().removeClass('glyphicon-ok');
		e.next().html(mes);
		return false;
	}
}
function AddElement(id) {
	var whatText = $('#'+id).text();
	console.log('用户添加了:'+whatText);
	var what = id.substr(3);//id为add数字，通过substr()提取数字
	if (publicElementId!=1) {
		switch(model){//after用于在选中元素后添加新元素，before在选中元素之前添加，model为全局变量，由用户通过id为changeModel的select通过onchange调用changeModel()方法。
			case '0':
				$('#'+selectElementBox).after(Creat('element',what));
				break;
			case '1':
				$('#'+selectElementBox).before(Creat('element',what));
				break;
			case '2':
				creatModle0(what);
				break;
		}
	}else{
		creatModle0(what);
	}
	function creatModle0(what) {//仅上方调用了两次，用于直接在editView最后添加新元素
		var data = $('.editView').html()+Creat('element',what);
		switch(what){
			case '0':
				$('.editView').html(data);
				break;
			case '1':
				$('.editView').html(data);
				break;
			case '2':
				$('.editView').html(data);
				break;
			case '3':
				$('.editView').html(data);
				break;
			case '4':
				$('.editView').html(data);
				break;
			case '5':
				$('.editView').html(data);
				break;
			case '6':
				$('.editView').html(data);
				break;
			case '-1':
				console.log('不可用');
				break;
		}
	}
}
function Creat(name,what) {//添加元素的函数
	switch(what){
		case '0':
			var element = '<input onkeyup="CheckInput(this.id)" class="form-control element" type="text" id="creatElementId'+creatElementId+'" name="'+name+'">';
			break;
		case '1':
			var element = '<textarea class="form-control element" id="creatElementId'+creatElementId+'" name="'+name+'"></textarea>';
			break;
		case '2':
			var element = '暂不提供图片传输';
			break;
		case '3':
			var element = '<select class="form-control element" id="creatElementId'+creatElementId+'" name="'+name+'"><option value ="test">test</option></select>';
			break;
		case '4':
			var element = '\
				<div class="element" id="creatElementId'+creatElementId+'">\
					<input type="hidden" id="radio_type" value="radio">\
					<input type="hidden" id="radio_margin" value="0">\
					<input type="hidden" id="radio_name" value="'+name+'">\
				</div>';
			break;
		case '5':
			var element = '\
				<div class="element" id="creatElementId'+creatElementId+'">\
				<input type="hidden" id="radio_type" value="checkbox">\
					<input type="hidden" id="radio_name" value="'+name+'">\
				</div>';
			break;
		case '6':
			var element = '<input class="form-control element" type="submit">';
			break;
	}
	var data = '\
		<div onclick="ClickElement(this.id)" id="publicElementId'+publicElementId+'" class="form-group elementBox has-feedback">\
			<label for="creatElementId'+creatElementId+'" class="col-sm-2 control-label">'+name+'</label>\
			<div class="col-sm-10">'+element+'\
				<input type="hidden" id="publicElementId'+publicElementId+'_what" value="'+what+'">\
				<span class="help-block"></span>\
				<span class="glyphicon form-control-feedback"></span>\
			</div>\
		</div>';
	publicElementId++;//给元素最外层div添加唯一id
	creatElementId++;//给元素添加唯一id
	return data;
}
function delElement() {//删除元素函数
	$('#'+selectElementBox).remove();
	$('.left').html('');
}
function changeModel(i) {//改变model的函数，用户通过id为changeModel的select通过onchange调用该方法
	model = i;
}
// 专用函数
function SelectChange(id) {
	var e = $('#'+id);
	if($('#'+selectElementBox).find('#'+selectElement+'_preg').length > 0) {
		$('#'+selectElementBox).find('#'+selectElement+'_preg').val(e.val());
	}else{
		$('#'+selectElementBox).find('.element').parent().append('<input id="'+selectElement+'_preg" type="hidden" value="'+e.val()+'">');
	}
	selectPreg = e.find("option:selected").text()+'('+e.val()+')';
}
function addOption(id) {
	var arr = new Array();
	var option = $('#'+id).parent().find('textarea').val();
	arr=option.split('\n');
	$('#'+selectElement).html("");
	for(var i=0;i<arr.length;i++)
	{
		if (arr[i]!='') {
			$('#'+selectElement).html($('#'+selectElement).html()+"<option value='"+arr[i]+"'>"+arr[i]+"</option>");
		}
	}
}