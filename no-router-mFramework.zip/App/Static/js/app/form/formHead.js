var bgModle = '#';
$('.formHead').click(function () {
	var data = '\
		<div class="form-group has-feedback">\
			<label for="label">设置标题：</label>\
			<input onkeyup="ChangeHead(this.id)" class="form-control" type="text" id="titleC" value="">\
			<label for="label">标题字体大小：</label>\
			<input onkeyup="ChangeHead(this.id)" class="form-control" type="text" id="titleSize" value="">\
			<label for="label">标题位置：</label>\
			<select onchange="ChangeHead(this.id)" id="titleStyle" class="form-control">\
				<option value="left">居左</option>\
				<option value="center">剧中</option>\
				<option value="right">居右</option>\
			</select>\
			<label for="label">整体背景：</label>\
			<select onchange="chooseBg(this.value)" id="chooseBg" class="form-control">\
				<option value="color">纯色</option>\
				<option value="image">图片</option>\
			</select>\
			<div id="changeBgBox">\
				<label for="inputBgColor">颜色代码：</label>\
				<label class="radio-inline">\
					<input type="radio" name="colormodle" onchange="chooseBg(this.value)" value="rgb"> RGB格式\
				</label>\
				<label class="radio-inline">\
					<input type="radio" name="colormodle" onchange="chooseBg(this.value)" value="#" checked="checked"> #格式\
				</label>\
				<input id="inputBgColor" class="form-control" onkeyup="chooseBg()" type="text" value="">\
				<span class="help-block"></span>\
			</div>\
		</div>';
	$('.left').html(data);
});
function ChangeHead(id) {
	var e = $('#'+id);
	var h = $('.formHead');
	switch(id){
		case 'titleC':
			h.find('#title').text(e.val());
			break;
		case 'titleSize':
			h.find('#title').css('font-size',e.val()+'px');
			break;
		case 'titleStyle':
			h.css('text-align',e.val());
			break;
	}
}
function chooseBg(i) {
	switch(i){
		case 'rgb':
			bgModle = i;
			break;
		case '#':
			bgModle = i;
			break;
		case 'color':
			var data = '\
				<label for="inputBgColor">颜色代码：</label>\
				<label class="radio-inline">\
					<input type="radio" name="colormodle" onchange="chooseBg(this.value)" value="rgb" '+checkModle(1)+'>RGB格式\
				</label>\
				<label class="radio-inline">\
					<input type="radio" name="colormodle" onchange="chooseBg(this.value)" value="#" '+checkModle(2)+'>#格式\
				</label>\
				<input id="inputBgColor" class="form-control" onkeyup="chooseBg()" type="text" value="">\
				<span class="help-block"></span>\
			';
			$('#changeBgBox').parent().find('#changeBgBox').html(data);
			break;
		case 'image':
			var data = '\
				<label for="inputBgUrl">图片链接：</label>\
				<input id="inputBgUrl" class="form-control" onchange="chooseBg()" type="text" value="">\
				<span class="help-block"></span>\
			';
			$('#changeBgBox').parent().find('#changeBgBox').html(data);
			break;
		default:
			if($('#inputBgColor').length > 0) {
				var color = $('#inputBgColor').val();
				if (bgModle=='rgb') {var data = 'rgb('+color+')';}
				if (bgModle=='#') {var data = color;}
			}
			if($('#inputBgUrl').length > 0) {
				var url = $('#inputBgUrl').val();
				var data = 'url(\''+url+'\')';
			}
			$('.editView').parent().css('background',data);
			break;
	}
	function checkModle(a) {
		if (bgModle=='rgb') {
			if (a==1) {
				return 'checked="checked"';
			}
			if (a==2) {
				return '';
			}
		}
		if (bgModle=='#') {
			if (a==2) {
				return 'checked="checked"';
			}
			if (a==1) {
				return '';
			}
		}
	}
}