<?php

class adminController extends Controller
{
    public function adminAction()
    {
        $action = new adminModel();
        $admin = $action->start();
        if (!isset($_SESSION['admin'])) {
            // 登陆
            if (isset($_POST['submit'])) {
                $result = $action->login($_POST['user'], $_POST['pwd']);
                if ($result['code'] == '300') {
                    echo "<script>window.parent.location.reload()</script>";
                } elseif ($result['code'] == '303') {
                    echo "<script>
                        var du = window.parent.document.getElementById('user');
                        du.parentNode.children[1].innerHTML='{$result['mes']}';
                        du.parentNode.children[2].classList.add('glyphicon-remove');
                        du.parentNode.parentNode.classList.add('has-error');
                        </script>";
                } elseif ($result['code'] == '302') {
                    echo "<script>
                        var du = window.parent.document.getElementById('user');
                        var dp = window.parent.document.getElementById('pwd');
                        du.parentNode.children[1].innerHTML='';
                        du.parentNode.children[2].classList.remove('glyphicon-remove');
                        du.parentNode.parentNode.classList.remove('has-error');
                        dp.parentNode.parentNode.classList.add('has-error');
                        dp.parentNode.children[1].innerHTML='{$result['mes']}';
                        dp.parentNode.children[2].classList.add('glyphicon-remove');
                        </script>";
                } elseif ($result['code'] == '301') {
                    echo "<script>alert('{$result['mes']}');</script>";
                }
            }
            $this->render('admin' . DS . 'login');
        } else {
            // 退出登录
            if (isset($_POST['logout'])) {
                $_SESSION['admin'] = null;
            }
            // 获取文件列表
            $fileList = $action->fileList();

            switch ($admin['identity']) {
                case '0':
                    $admin['identity'] = '超级管理员';
                    break;
            }
            $data = array(
                'name' => $admin['name'],
                'identity' => $admin['identity'],
                'fileList'=>$fileList
            );
            $this->render('admin' . DS . 'admin', $data);
        }
    }
}