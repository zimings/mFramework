<?php
class testController extends Controller
{
    public function testAction()
    {
        $action = new userModel();
        if (isset($_POST['submit'])) {
            $code = (string)$_POST['code'];
            $ret = $action->test($code);
            switch ($ret) {
                case 'empty':
                    echo '<script>window.parent.document.getElementById("help-block").innerText="邀请码为空！"</script>';
                    break;
                case '200ok':
                    echo '<script>window.parent.location.href="'.__WEB__.'?M=user&A=registered"</script>';
                    break;
                case 'used':
                    echo '<script>window.parent.document.getElementById("help-block").innerText="邀请码已被使用！"</script>';
                    break;
                case 'serverError':
                    echo '<script>window.parent.document.getElementById("help-block").innerText="服务错误！请联系管理员！"</script>';
                    break;
                case 'none':
                    echo '<script>window.parent.document.getElementById("help-block").innerText="无效的邀请码！"</script>';
                    break;
            }
        }
        $this->render('test');
    }
}