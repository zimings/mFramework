<?php

class userController extends Controller
{
    public function homeAction()
    {
        $M = new userModel();
        /*加载设置*/
        $setting = $M->getSetting();
        $setting = json_decode($setting['setting']);
        /*注入用户设置内容*/
        $this->render_once($setting->onePageNum, 'onePageNum');
        /*加载文章列表*/
        $dataPer = array();
        $dataPub = array();
        foreach ($M->article() as $value) {
            if (!empty($value['otherInfo']->tag)) {
                $tag = '<span class="glyphicon glyphicon-tag"></span>&nbsp' . $value['otherInfo']->tag;
            } else {
                $tag = '';
            }
            $content = '<div class="row">
                    <a href="' . __WEB__ . '?c=article&a=article&ID=' . $value['articleId'] . '">
                        <div class="col-xs-12 content_home">
                            <span class="title">' . $value['title'] . '</span><br>
                            <span class="time">' . $value['time'] . '<br>' . $tag . '</span>
                            <p>' . $M->truncateStr($value['content'], 100) . '</p>
                        </div>
                    </a>
                </div>';
            if ($value['personal'] == '1') {
                array_push($dataPer, $content);
            } else {
                array_push($dataPub, $content);
            }
        }
        $this->render_once($M->pages($dataPer, (int)$setting->onePageNum), 'contentPer');
        $this->render('user' . DS . 'home', $M->pages($dataPub, (int)$setting->onePageNum), 'contentPub');

        if (isset($_POST['setting'])) {/*更改用户偏好设置*/
            $settings = array(
                'onePageNum' => $_POST['setting_onePageNum']
            );
            $ret = $M->changeSetting($settings);
            if ($ret) echo "<script>window.parent.showMsg('更改成功！',2000);setTimeout('window.parent.location.reload()',1000)</script>";
        }
        if (isset($_POST['headPortraitUrl'])) {/*更改头像*/
            $result = $M->changeInfo('', '', '', $_POST['headPortraitUrl']);
            if ($result) {
                $M->updateSession();
                echo "<script>window.parent.showMsg('即将刷新！');</script>";
            } else {
                echo "<script>window.parent.showMsg('插入数据库失败！');</script>";
            }
        } elseif (isset($_POST['change'])) {/*更改信息*/
            $result = $M->changeInfo($_POST['name'], $_POST['phone'], $_POST['signature']);
            if (is_array($result)) {
                echo "<script>window.parent.showMsg('更改失败！{$result["mes"]}')</script>";
            } else {
                if ($result) {
                    $M->updateSession();
                    echo "<script>window.parent.showMsg('更改成功！',2000);setTimeout('window.parent.location.reload()',1000)</script>";
                } else {
                    echo "<script>window.parent.showMsg('更改失败！');</script>";
                }
            }
        }
    }

    public function loginAction()
    {
        $M = new userModel();
        if (isset($_POST['login'])) {
            $result = $M->login($_POST['user'], $_POST['pwd']);
            if (is_array($result)) {
                if ($result['code'] == '103') {
                    echo "<script>
                        var du = window.parent.document.getElementById('user');
                        var btn = window.parent.document.getElementById('submit');
                        du.parentNode.children[1].innerHTML='{$result['mes']}';
                        du.parentNode.children[2].classList.add('glyphicon-remove');
                        du.parentNode.parentNode.classList.add('has-error');
                        btn.classList.remove('disabled');
                        btn.value='重新登陆';
                        </script>";
                } elseif ($result['code'] == '102') {
                    echo "<script>
                        var du = window.parent.document.getElementById('user');
                        var dp = window.parent.document.getElementById('pwd');
                        var btn = window.parent.document.getElementById('submit');
                        du.parentNode.children[1].innerHTML='';
                        du.parentNode.children[2].classList.remove('glyphicon-remove');
                        du.parentNode.parentNode.classList.remove('has-error');
                        dp.parentNode.parentNode.classList.add('has-error');
                        dp.parentNode.children[1].innerHTML='{$result['mes']}';
                        dp.parentNode.children[2].classList.add('glyphicon-remove');
                        btn.classList.remove('disabled');
                        btn.value='重新登陆';
                        </script>";
                } elseif ($result['code'] == '101') {
                    echo "<script>alert('" . $result['mes'] . "');</script>";
                }
            } elseif ($result) {
                if ($_POST['fromWhere'] == 'login') {
                    $successReturn = 'window.parent.location.href="' . __WEB__ . '";';
                } else {
                    $successReturn = 'window.parent.location.reload();';
                }
                echo "<script>{$successReturn}</script>";
            }
        }
        $this->render('user' . DS . 'login');
    }

    public function logoutAction()
    {
        session_destroy();
        foreach ($_COOKIE as $key => $value) {
            setCookie($key, "", time() - 1);
        }
        echo '<script>location.href="' . __WEB__ . '"</script>';
    }

    public function registeredAction()
    {
        if (!$_SESSION['verifyState']) {
            header('refresh:3;url=http://' . $_SERVER['SERVER_NAME'] . __WEB__);
            echo '该功能只为内测用户开放！即将返回首页。 ';
            exit();
        }

        $M = new userModel();
        if (isset($_POST['registered'])) {
            if (!empty($_POST['verification_code'])) {
                $checkVerification['input_code'] = $_POST['verification_code'];
                $checkVerification['session_code'] = $_SESSION['verification_code'];
                $checkVerification['startTime'] = $_SESSION['startTime'];
                $result = $M->registered($_POST['user'], $_POST['pwd'], $_POST['name'], $_POST['phone'], $checkVerification);
                if (is_array($result)) {
                    echo "<script>alert('注册失败！" . $result['mes'] . "')</script>";
                } else {
                    if ($result) {
                        echo "<script>alert('注册成功！请登录！');window.parent.location.href='" . __WEB__ . "?M=user&A=login';</script>";
                    } else {
                        echo "<script>alert('注册失败！请联系管理员！')</script>";
                    }
                }
            } else {
                echo "<script>alert('请输入验证码！')</script>";
            }
        } elseif (isset($_POST['sendVerification'])) {
            $ret = $M->sendVerification($_POST['sendVerification']);
            if ($ret['result'] == '0') {
                $_SESSION['verification_code'] = $ret['code'];
                $_SESSION['startTime'] = time();
                echo "<script>console.log('sendCodeSuccess!')</script>";
            } elseif ($ret['code'] == '201') {
                echo "<script>console.log('error:{$ret['mes']}')</script>";
                echo "<script>alert('error:{$ret['mes']}')</script>";
            }
        }
        $this->render('user' . DS . 'registered');
    }
}