<?php
class indexController extends Controller
{
    public function indexAction()
    {
        $M  = new indexModel();
        $articleList = $M->articleList(30);
        $outPut = array();
        foreach ($articleList as $value) {
            if (!empty($value['otherInfo']->tag)) {
                $tag = '<span class="glyphicon glyphicon-tag"></span>&nbsp'.$value['otherInfo']->tag;
            } else {
                $tag = '';
            }
            $data = '<div class="row">
                    <!-- 作者信息 -->
                    <div class="col-xs-3 authorInfo">
                        <a href="'.__WEB__.'?c=article&a=author&uid='.$value['uid'].'"><img alt="'.$value['name'].'" src="'.$value['headPortrait'].'" class="img-responsive img-thumbnail"></a>
                        <span>'.$value['name'].'</span>
                    </div>
                    <a href="'.__WEB__.'?c=article&a=article&ID='.$value['articleId'].'">
                        <div class="col-xs-9 content">
                            <span class="title">'.$value['title'].'</span><br>
                            <span class="time">'.$value['time'].'<br>'.$tag.'</span>
                            <p>'.$M->truncateStr($value['content'], 100).'</p>
                        </div>
                    </a>
                </div>';
            array_push($outPut, $data);
        }
        $this->render('index', $M->pages($outPut, 6), 'content');
    }
}
