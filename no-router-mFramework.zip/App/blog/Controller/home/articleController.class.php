<?php
class articleController extends Controller
{
    public function articleAction()
    {
        $M = new articleModel();
        $data = $M->show();
        if ($data['uid'] == $_SESSION['user']['uid']) {
            $this->render_once(1, 'isAuthor');
            if ($data['personal'] == '1') {
                $data['personal'] = 'checked';
            }
        }
        if (isset($_POST['submit'])) {
            if (isset($_POST['personal'])) {
                $personal = '1';
            } else {
                $personal = '0';
            }
            $ret = false;
            if (!empty($_POST['content']) && !empty($_POST['title'])) {
                $ret = $M->change($_POST['title'], $_POST['content'], $_POST['otherInfo'], $personal, $_GET['ID']);
            }
            if ($ret) {
                echo "<script>alert('Success!');window.location.href='" . __WEB__ . "?M=article&A=article&ID=" . $_GET['ID'] . "';</script>";
            } else {
                echo "<script>alert('Error!')</script>";
            }
        }
        if ($_POST['deleteThis'] == 'delete') {
            $M->deleteThis($_GET['ID']);
        }
        $this->render('article'.DS.'article', $data);
    }

    public function newArticleAction()
    {
        $M = new articleModel();
        if (isset($_POST['submit'])) {
            $ret = false;
            if (!empty($_POST['content']) && !empty($_POST['title'])) {
                $ret = $M->newArticle($_POST['title'], $_POST['content'], $_POST['otherInfo'], $_POST['personal']);
            }
            if ($ret) {
                echo "<script>alert('Success!');window.location.href='".__WEB__."?M=user&A=home';</script>";
            } else {
                echo "<script>alert('Error!')</script>";
            }
        }
        $this->render('article'.DS.'newArticle');
    }

    public function authorAction()
    {
        $M = new articleModel();
        $data = $M->author($_GET['uid']);
        $outPut = array();
        foreach ($data['articleList'] as $value) {
            $content = '<div class="row">
                    <a href="'.__WEB__.'?c=article&a=article&ID='.$value['articleId'].'">
                        <div class="col-xs-12 content">
                            <span class="title">'.$value['title'].'</span><br>
                            <span class="time">'.$value['time'].'</span>
                            <p>'.$M->truncateStr($value['content'], 100).'</p>
                        </div>
                    </a>
                </div>';
            array_push($outPut, $content);
        }
        $data = array(
            'name' => $data['name'],
            'headPortrait' => $data['headPortrait'],
            'signature' => $data['signature']
        );
        $this->render_once($data);
        $this->render('article'.DS.'author', $M->pages($outPut, 3), 'content');
    }

    public function searchAction()
    {
        $M = new searchModel();
        $outPut = array();
        $this->render_once($_GET['flag'], 'flag');
        if (isset($_GET['keyWords']) && !empty($_GET['keyWords'])) {
            $articleList = $M->search($_GET['keyWords'], $_GET['flag']);
            if (is_bool($articleList) && !$articleList) {
                $this->render_once('请勿随意更改！', 'content');
            } else {
                if (empty($articleList)) {
                    $this->render_once('无结果！', 'content');
                } else {
                    foreach ($articleList as $value) {
                        $data = '<div class="row">
                        <!-- 作者信息 -->
                        <div class="col-xs-3 authorInfo">
                            <a href="' . __WEB__ . '?c=article&a=author&uid=' . $value['uid'] . '"><img alt="' . $value['name'] . '" src="' . $value['headPortrait'] . '" class="img-responsive img-thumbnail"></a>
                            <span>' . $value['name'] . '</span>
                        </div>
                        <a href="' . __WEB__ . '?c=article&a=article&ID=' . $value['articleId'] . '">
                            <div class="col-xs-9 content">
                                <span class="title">' . $value['title'] . '</span><br>
                                <span class="time">' . $value['time'] . '</span>
                                <p>' . $M->truncateStr($value['content'], 100) . '</p>
                            </div>
                        </a>
                    </div>';
                        array_push($outPut, $data);
                    }
                    $this->render_once($M->pages($outPut, 6), 'content');
                }
            }
        } else {
            $this->render_once('请输入关键字！', 'content');
        }
        $this->render('search', $_GET['keyWords'], 'keyWords');
    }
}