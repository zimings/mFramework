<?php

class searchController extends Controller
{
    public function searchAction()
    {
        $M = new searchModel();
        $outPut = array();
        $this->render_once($_GET['flag'], 'flag');
        if (isset($_GET['keyWords']) && !empty($_GET['keyWords'])) {
            $articleList = $M->search($_GET['keyWords'], $_GET['flag']);
            if (is_bool($articleList) && !$articleList) {
                $this->render_once('请勿随意更改！', 'content');
            } else {
                if (empty($articleList)) {
                    $this->render_once('无结果！', 'content');
                } else {
                    foreach ($articleList as $value) {
                        $data = '<div class="row">
                        <!-- 作者信息 -->
                        <div class="col-xs-3 authorInfo">
                            <a href="' . __WEB__ . '?c=article&a=author&uid=' . $value['uid'] . '"><img alt="' . $value['name'] . '" src="' . $value['headPortrait'] . '" class="img-responsive img-thumbnail"></a>
                            <span>' . $value['name'] . '</span>
                        </div>
                        <a href="' . __WEB__ . '?c=article&a=article&ID=' . $value['articleId'] . '">
                            <div class="col-xs-9 content">
                                <span class="title">' . $value['title'] . '</span><br>
                                <span class="time">' . $value['time'] . '</span>
                                <p>' . $M->truncateStr($value['content'], 100) . '</p>
                            </div>
                        </a>
                    </div>';
                        array_push($outPut, $data);
                    }
                    $this->render_once($M->pages($outPut, 6), 'content');
                }
            }
        } else {
            $this->render_once('请输入关键字！', 'content');
        }
        $this->render('search', $_GET['keyWords'], 'keyWords');
    }
}