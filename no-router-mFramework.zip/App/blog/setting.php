<?php

class setting implements settings
{
    public function loadSetting()
    {
        $this->loadGlobalData();
        $this->loadStaticPath();
    }

    private function loadGlobalData()
    {
        $controller = CONTROLLER . 'Controller';
        $controller::$tpl->assign('name_self', $_SESSION['user']['name']);
        $controller::$tpl->assign('phone_self', $_SESSION['user']['phone']);
        $controller::$tpl->assign('user_self', $_SESSION['user']['user']);
        $controller::$tpl->assign('uid_self', $_SESSION['user']['uid']);
        $controller::$tpl->assign('signature_self', $_SESSION['user']['signature']);
        $controller::$tpl->assign('headPortrait_self', $_SESSION['user']['headPortrait']);
    }

    private function loadStaticPath()
    {
        //静态文件路径
        define('__STATIC__', __ROOT__ . 'App' . DS . 'Static' . DS);
        //页面路径
        define('__CSS__', __WEB__ . 'App/Static/css/');
        define('__IMG__', __WEB__ . 'App/Static/images/');
        define('__JS__', __WEB__ . 'App/Static/js/');
        define('__LIB__', __WEB__ . 'App/Static/library/');
    }
}