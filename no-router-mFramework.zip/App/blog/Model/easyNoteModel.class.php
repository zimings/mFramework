<?php
class easyNoteModel extends Model
{
    public function getList()
    {
        $list = self::$mysql->getRows('*', 'EasyNote', array('uid' => $_SESSION['user']['uid']));
        return $list;
    }
}