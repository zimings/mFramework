<?php

/**
 * user
 */
class userModel extends Model
{
    /*文章列表*/
    public function article()
    {
        $result = self::$mysql->getRows('*', 'article', array('uid' => $_SESSION['user']['uid']));
        if (count($result) == 1) {
            $article[0] = $result;
            $article[0]['otherInfo'] = json_decode($article[0]['otherInfo']);
        } else {
            $article = $result;
            foreach ($article as $key => $value) {
                $ret = self::$mysql->getRows('name,headPortrait', 'user', array('uid' => $value['uid']));
                $name = $ret['name'];
                $headPortrait = $ret['headPortrait'];
                $article[$key]['name'] = $name;
                $article[$key]['headPortrait'] = $headPortrait;
                $article[$key]['otherInfo'] = json_decode($article[$key]['otherInfo']);
            }
        }
        return $article;
    }

    /*更改信息*/
    public function changeInfo($name, $phone, $signature, $headPortraitUrl = null)
    {
        if ($headPortraitUrl == null) {
            $ret = self::$mysql->getOneRow('user', 'user', array('phone' => $phone));
            if (empty($ret)) {
                if (empty($name)) {
                    $name = '请设置昵称';
                }
                $data = array(
                    'name' => $name,
                    'phone' => $phone
                );
                $ret1 = self::$mysql->update('user', $data, array('uid' => $_SESSION['user']['uid']));
                $data = array(
                    'signature' => $signature
                );
                $ret2 = self::$mysql->update('userMore', $data, array('uid' => $_SESSION['user']['uid']));
                return $ret1 && $ret2;
            } else {
                return array('mes' => '手机号已被使用', 'code' => '202');
            }
        } else {
            return self::$mysql->update('user', array('headPortrait' => $headPortraitUrl), array('uid' => $_SESSION['user']['uid']));
        }
    }

    /*获取用户设置*/
    public function getSetting()
    {
        return self::$mysql->getOneRow('setting', 'userMore', array('uid' => $_SESSION['user']['uid']));
    }

    /*更改用户设置*/
    public function changeSetting($setting)
    {
        $arr = array();
        foreach ($setting as $key => $value) {
            $arr[$key] = $value;
        }
        $data['setting'] = json_encode($arr);
        return self::$mysql->update('userMore', $data, array('uid' => $_SESSION['user']['uid']));
    }

    /*登陆*/
    public function login($account, $pwd)
    {
        if (preg_match("/^1[34578]\d{9}$/", $account)) {
            $where = array("phone" => $account);
        } else {
            $where = array("user" => $account);
        }
        $result = self::$mysql->getOneRow('*', 'user', $where);
        if (empty($result)) {
            return array('mes' => '用户不存在', 'code' => '103');
        } else {
            if (password_verify($pwd, $result['pwd'])) {
                unset($result['pwd']);
                $_SESSION['user'] = $result;
                $signature = self::$mysql->getOneRow('signature', 'userMore', array('uid' => $result['uid']));
                $_SESSION['user']['signature'] = $signature['signature'];
                if (isset($_SESSION['user'])) {
                    return true;
                } else {
                    return array('mes' => '登录失败，请联系管理员！', 'code' => '101');
                }
            } else {
                return array('mes' => '密码错误', 'code' => '102');
            }
        }
    }

    /*注册*/
    public function registered($user, $pwd, $name, $phone, $checkVerification)
    {
        $DB = self::$mysql->getOneRow('user,phone', 'user', array('user' => $user));
        if ($user == $DB['user']) {
            $result= array('mes' => '用户名已被使用', 'code' => '201');
        } elseif ($phone == $DB['phone']) {
            $result= array('mes' => '该手机号已被注册', 'code' => '202');
        } else {
            $ret = $this->checkVerification($checkVerification['input_code'], $checkVerification['session_code'], $checkVerification['startTime']);
            $obj = json_decode($ret);
            if ($obj->code == '900') {
                if (empty($name)) {
                    $name = '请设置昵称';
                }
                $pwd = password_hash($pwd, PASSWORD_DEFAULT);
                $data = array('user' => $user, 'pwd' => $pwd, 'name' => $name, 'phone' => $phone);
                $ret1 = self::$mysql->insert('user', $data);
                $result = self::$mysql->getRows('uid', 'user', array('user' => $user));
                $ret2 = self::$mysql->insert('userMore', array('uid' => $result['uid']));
                return $ret1 && $ret2;
            } else {
                return array('mes' => $obj->mes, 'code' => $obj->code);
            }
        }
        return array('mes' => $result['mes'], 'code' => $result['code']);
    }

    public function test($code)
    {
        if (!empty($code)) {
            $result = self::$mysql->getOneRow('*', 'private', array('code' => $code));
            if (!empty($result)) {
                if (!(bool)$result['state']) {
                    $ret = self::$mysql->update('private', array('state' => '1'), array('code' => $code));
                    if ($ret) {
                        $_SESSION['verifyState'] = true;
                        return '200ok';
                    } else {
                        return 'serverError';
                    }
                } else {
                    return 'used';
                }
            } else {
                return 'none';
            }
        } else {
            return 'empty';
        }
    }
}
