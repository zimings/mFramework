<?php

/**
 * admin
 */
class adminModel extends Model
{
    public function start()
    {
        if (isset($_SESSION['admin'])) {
            $data = array(
                'name' => $_SESSION['admin']['name'],
                'identity' => $_SESSION['admin']['identity']
            );
            return $data;
        } else {
            return false;
        }
    }

    public function login($account, $pwd)
    {
        if (preg_match("/^1[34578]\d{9}$/", $account)) {
            $where = array("phone" => $account);
        } else {
            $where = array("name" => $account);
        }
        $result = self::$mysql->getOneRow('*', 'admin', $where);
        if (empty($result)) {
            return array('mes' => '用户不存在', 'code' => '303');
        } else {
            if (md5($pwd) == $result['pwd']) {
                $_SESSION['admin'] = $result;
                if (isset($_SESSION['admin'])) {
                    return array('mes' => '登陆成功', 'code' => '300');
                } else {
                    return array('mes' => '登录失败，SESSION创建失败！', 'code' => '301');
                }
            } else {
                return array('mes' => '密码错误', 'code' => '302');
            }
        }
    }

    public function fileList()
    {
        function getDirTree($path)
        {
            $dir = scandir($path);
            foreach ($dir as $key => $value) {
                if ($value == '.' || $value == '..') {
                    unset($dir[$key]);
                } else {
                    if (!is_dir($path . $value)) {
                        $dir[$value]['attr'] = 'file';
                        $dir[$value]['size'] = filesize($path . $value);
                        $dir[$value]['content'] = file_get_contents($path . $value);
                    } else {
                        $dir[$value]['attr'] = 'dir';
                        $dir[$value]['list'] = getDirTree($path . $value . DS);
                    }
                    unset($dir[$key]);
                }
            }
            return $dir;
        }

        $fileList = getDirTree(__APP__);
        return $fileList;
    }
}
