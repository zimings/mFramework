<?php
/**
* search
*/
class searchModel extends Model
{
    public function search($keyWords, $flag)
    {
        if ($flag == 'personal') {
            $where = array('title' => '%'.$keyWords.'%', 'personal' => '0', 'uid' => $_SESSION['user']['uid']);
        } elseif ($flag == 'public') {
            $where = array('title' => '%'.$keyWords.'%', 'personal' => '0');
        } else {
            return false;
        }
        $result = self::$mysql->search('*', 'article', $where);
        $arr = $result;
        foreach ($arr as $key => $value) {
            $val = self::$mysql->getOneRow('name,headPortrait', 'user', array('uid' => $value['uid']));
            $result[$key]['name'] =  $val['name'];
            $result[$key]['headPortrait'] =  $val['headPortrait'];
        }
        return $result;
    }
}
