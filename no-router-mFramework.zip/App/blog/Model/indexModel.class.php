<?php
/**
* 首页
*/
class indexModel extends Model
{
    public function articleList($limit)
    {
        $where = array('personal' => '0');
        $data = self::$mysql->getRows('*', 'article', $where, 0, $limit);
        foreach ($data as $key => $value) {
            $ret = self::$mysql->getOneRow('name,headPortrait','user', array('uid' => $value['uid']));
            $name = $ret['name'];
            $headPortrait = $ret['headPortrait'];
            $data[$key]['name'] = $name;
            $data[$key]['headPortrait'] = $headPortrait;
            $data[$key]['otherInfo'] = json_decode($data[$key]['otherInfo']);
        }
        return $data;
    }
}
