<?php
/**
* article
*/
class articleModel extends Model
{
    /*作者信息*/
    public function author($uid)
    {
        $userInfo = self::$mysql->getOneRow('name,headPortrait', 'user', array('uid' => $uid));
        $userInfo['signature']=self::$mysql->getOneRow('signature', 'userMore', array('uid' => $uid))['signature'];
        $articleList = self::$mysql->getRows('*', 'article', array('uid' => $uid, 'personal' => '0'));
        return array(
            'name'=>$userInfo['name'],
            'headPortrait'=>$userInfo['headPortrait'],
            'signature'=>$userInfo['signature'],
            'articleList'=>$articleList
        );
    }
	public function show()
	{
		$article = self::$mysql->getOneRow('*', 'article', array('articleId' => $_GET['ID']));
		$author = self::$mysql->getOneRow('name,headPortrait', 'user', array('uid' => $article['uid']));
		$signature = self::$mysql->getOneRow('signature', 'userMore', array('uid' => $article['uid']));
		$otherInfo = json_decode($article['otherInfo']);
		$data = array(
			'author' => $author['name'],
			'headPortrait' => $author['headPortrait'],
			'title' => $article['title'],
			'time' => $article['time'],
			'content' => $article['content'],
			'signature' => $signature['signature'],
			'uid' => $article['uid'],
			'personal' => $article['personal'],
            'otherInfo' => $otherInfo
			);
		return $data;
	}
	public function change($title, $content, $otherInfo, $personal, $articleId)
	{
		$data = array(
			'title' => $title,
			'content' => $content,
			'personal' => $personal,
            'otherInfo' => $otherInfo
			);
		$where = array(
			'uid' => $_SESSION['user']['uid'],
			'articleId' => $articleId);
		$ret = self::$mysql->update('article', $data, $where);
		if ($ret) {
			return true;
		} else {
			return false;
		}
	}
	public function deleteThis($articleId)
	{
		$where = array(
			'uid' => $_SESSION['user']['uid'],
			'articleId' => $articleId
			);
		$ret = self::$mysql->delete('article', $where);
		if ($ret) {
			return true;
		} else {
			return false;
		}
	}
    public function newArticle($title, $content, $otherInfo, $personal)
    {
        $time = date("Y-m-d H:i:s");
        if (empty($personal)) {
            $personal = 0;
        }
        $data = array(
            'title' => $title,
            'time' => $time,
            'content' => $content,
            'uid' => $_SESSION['user']['uid'],
            'personal' => $personal,
            'otherInfo' => $otherInfo
        );
        $ret = self::$mysql->insert('article', $data);
        if ($ret) {
            return 1;
        } else {
            return 0;
        }
    }
}
