## 创建数据库相关信息：（后期通过install.php实现）
- 例如：
    - `CREATE USER 'ziming'@'%' IDENTIFIED BY 'weiziming9941';`
    - `CREATE DATABASE Mdb;`
    - `GRANT ALL ON Mdb.* TO 'ziming'@'%';`
    - `FLUSH PRIVILEGES;`

## 文件相关：
- 网站根目录下的index.php为唯一入口，首先定义改文件所在目录为根目录，定义常量__ROOT__
    - 加载base.php，里面定义常量并加载控制器、模块和配置文件Config.php，定义类sysBase，loadConfig方法为辅助定义常量。
    - Config.json为配置文件

## 控制器：
- 参数传递
    - $_GET['c'] 控制器
    - $_GET['p'] 平台
    - $_GET['a'] 活动
    - $_GET['API'] 接口，API值为1时请求接口

## API调用：
- 参数传递
    - $_GET['API']值为1时请求API目录下的api.class.php，该文件接收两个参数：
        - $_GET['API_M'] 目录
        - $_GET['API_A'] 调用的文件
	参考链接：http://127.0.0.1/mFramework/?API=1&API_M=index&API_A=Index

## 模板解析引擎
- 在Controller中定义
    -render_once(要渲染的数据, 在模板中的名称defalut=null)
    -render(模板文件相对App/View的路径, 要渲染的数据defalut=null, 在模板中的名称defalut=null)
    - 原始方法
        - assign()方法插入数据
        - show()方法展示
###### 自定义标签label：只能添加静态内容！！！（最先渲染）
- 通过正则表达式替换label标签的内容。（单引号双引号都可使用）
- `{label:labelName attr1="value1" attr2="value2"}`
    - labelName:自定义标签的名字
    - attr1,attr2:属性（自定义）
    - value:你定义的属性的值
- 所有标签文件放在Label文件夹下
    - 如`{label:user showInf="1"}`
    - 在Label文件夹下存在user.php文件。
    - 在文件中定义与该文件相同名称的函数，模板引擎会向该函数注入包含标签属性和值的数组。如  
        `function user($Attr){}`
    - 若有多个属性，则形为$Attr=array("attr1"=>"value1","attr2"=>"value2");
    - 注：所有属性值为字符串

## 内置label：
- rely：默认加载jq、bootstrap，可使用css属性+值或者js+值增加加载Label文件夹下的css或js（Label文件夹在Public的css和js中）
    - `{label:rely css="nav"}`额外加载了<link rel="stylesheet" type="text/css" href="/Public/css/Label/nav.css">
    - js相同道理，额外加载一个script标签。
    - 注：如果加载多个，请用逗号隔开，如{label:rely css="css1,css2"}。
- user:无默认加载内容
    - login：值为1时展示一个登陆框，class col-sm-6大小，不需要不用填写此项。
    - agreement 值为1时加载用户协议
## 返回码：json{"code":"","mes":""}
- 系统返回码
    - 001 API调用时get参数API不等于'1'，此参数用来判断请求类型，故只能为'1'。
- 用户登录返回code
    - 100登陆成功
    - 101登录失败（session创建失败）
    - 102密码错误
    - 103用户不存在
- 用户注册,更改信息
    - 200注册成功
    - 201用户名已被使用
    - 202手机号已被使用
    - 203手机号未做改动
- 管理员
    - 300登陆成功
    - 301登录失败（session创建失败）
    - 302密码错误
    - 303用户不存在
- 图片上传接口
    - code，值：
        - '1'，发生错误
        - '0'，成功
    - mes：错误信息（仅在error为'1'时有该值）
    - url：图片链接（仅在error为'1'时有该值）
- SMS
    - 900 Success!
    - 901 out time!
    - 902 Verification code error

## 常用方法：
- modell.class.php
    - 裁剪字符串
        ```
        public function truncateStr($str, $len, $replace='...')
        {
            $str = strip_tags($str);
            if (mb_strlen($str) >=  $len) {
                $ret = substr($str, 0, $len).$replace;
            } else {
                $ret = $str;
            }
            return $ret;
        }
        ```
        该方法用于裁剪过长字符串，第一个参数接收字符串，第二个设置预期长度，第三个可选，设置 替换成什么。
    - 内容分页  
    `public function pages($data, $num=8)`  
	得到对内容进行分页展示，$data是内容数组，每条内容一个位置。$num每页展示几条内容，默认8条。默认分页样式来自bootstrap。

## 内置接口
- upload -> image
    - 图片上传接口，会对文件类型进行两次，第一次通过`$_FILES["file"]["type"]`判断，第二次通过`API_base->fileTypeJudge()`方法读取文件内容进行判断
    - 返回信息格式json（具体内容在返回码中）